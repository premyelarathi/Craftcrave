import { createContext, useEffect, useMemo, useState } from 'react'
import { apiRequest, clientId } from '../api'

export const CartContext = createContext(null)

export function CartProvider({ children }) {
  const [items, setItems] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    apiRequest(`/cart/${clientId}`)
      .then(({ items: savedItems }) => setItems(savedItems))
      .catch((requestError) => setError(requestError.message))
  }, [])

  const addToCart = async (product) => {
    try {
      const result = await apiRequest(`/cart/${clientId}/items`, {
        method: 'POST',
        body: JSON.stringify({ productId: product.id }),
      })
      setItems(result.items)
      setError('')
    } catch (requestError) {
      setError(requestError.message)
    }
  }

  const updateQuantity = async (id, delta) => {
    const item = items.find((entry) => entry.id === id)
    if (!item) return
    try {
      const result = await apiRequest(`/cart/${clientId}/items/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ quantity: Math.max(0, item.quantity + delta) }),
      })
      setItems(result.items)
      setError('')
    } catch (requestError) {
      setError(requestError.message)
    }
  }

  const removeFromCart = async (id) => {
    try {
      const result = await apiRequest(`/cart/${clientId}/items/${id}`, { method: 'DELETE' })
      setItems(result.items)
      setError('')
    } catch (requestError) {
      setError(requestError.message)
    }
  }

  const clearCart = async () => {
    try {
      const result = await apiRequest(`/cart/${clientId}`, { method: 'DELETE' })
      setItems(result.items)
      setError('')
    } catch (requestError) {
      setError(requestError.message)
    }
  }

  const itemCount = useMemo(
    () => items.reduce((sum, item) => sum + item.quantity, 0),
    [items],
  )

  const subtotal = useMemo(
    () => items.reduce((sum, item) => sum + item.price * item.quantity, 0),
    [items],
  )

  const value = {
    items,
    itemCount,
    subtotal,
    error,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
  }

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}
