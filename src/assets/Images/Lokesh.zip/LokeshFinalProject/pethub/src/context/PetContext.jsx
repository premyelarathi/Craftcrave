import { createContext, useEffect, useState } from 'react'
import { apiRequest, clientId } from '../api'

export const PetContext = createContext(null)

export function PetProvider({ children }) {
  const [trackedPets, setTrackedPets] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    apiRequest(`/tracking/${clientId}`)
      .then(setTrackedPets)
      .catch((requestError) => setError(requestError.message))
  }, [])

  const updatePets = async (path, options) => {
    try {
      setTrackedPets(await apiRequest(path, options))
      setError('')
    } catch (requestError) {
      setError(requestError.message)
    }
  }

  const addPet = (pet) =>
    updatePets(`/tracking/${clientId}/pets`, {
      method: 'POST',
      body: JSON.stringify(pet),
    })

  const updatePet = (id, updates) =>
    updatePets(`/tracking/${clientId}/pets/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    })

  const deletePet = (id) =>
    updatePets(`/tracking/${clientId}/pets/${id}`, { method: 'DELETE' })

  const addVaccinationRecord = (petId, status) =>
    updatePets(`/tracking/${clientId}/pets/${petId}/vaccination`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    })

  const addReminder = (petId, text) =>
    updatePets(`/tracking/${clientId}/pets/${petId}/reminders`, {
      method: 'POST',
      body: JSON.stringify({ text }),
    })

  const toggleReminder = (petId, reminderId) =>
    updatePets(`/tracking/${clientId}/pets/${petId}/reminders/${reminderId}`, {
      method: 'PATCH',
    })

  return (
    <PetContext.Provider
      value={{
        trackedPets,
        error,
        addPet,
        updatePet,
        deletePet,
        addVaccinationRecord,
        addReminder,
        toggleReminder,
      }}
    >
      {children}
    </PetContext.Provider>
  )
}
