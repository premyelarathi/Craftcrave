import { FaMapMarkerAlt, FaPhoneAlt, FaRegClock } from "react-icons/fa";
import { images } from "../data/images";

function VetCard({ vet }) {
  return (
    <article className="overflow-hidden rounded-3xl border border-green-100 bg-white shadow-sm">
      <img
        src={images.vetConsultation}
        alt={vet.name}
        className="h-52 w-full object-cover"
      />

      <div className="space-y-4 p-5">
        <div>
          <h3 className="text-xl font-bold text-green-900">{vet.name}</h3>
          <p className="mt-2 flex items-center gap-2 text-sm text-gray-500">
            <FaMapMarkerAlt />
            {vet.area}, {vet.city}
          </p>
        </div>

        <div className="space-y-2 text-sm text-gray-600">
          <p className="flex items-center gap-2">
            <FaPhoneAlt />
            {vet.phone}
          </p>
          <p className="flex items-center gap-2">
            <FaRegClock />
            {vet.hours}
          </p>
        </div>

        <div>
          <p className="text-sm font-semibold text-green-800">Services</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {vet.services?.map((service) => (
              <span
                key={service}
                className="rounded-full bg-green-50 px-3 py-1 text-xs text-green-800"
              >
                {service}
              </span>
            ))}
          </div>
        </div>

        <a
          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(vet.address)}`}
          target="_blank"
          rel="noreferrer"
          className="block rounded-full bg-green-800 px-4 py-3 text-center text-sm font-semibold text-white hover:bg-green-900"
        >
          View on Map
        </a>
      </div>
    </article>
  );
}

export default VetCard;