import { FaShoppingCart } from "react-icons/fa";
import { useCart } from "../hooks/useCart";
import { formatCurrencyINR } from "../utils/format";

function ProductCard({ product }) {
  const { addToCart } = useCart();

  return (
    <article className="overflow-hidden rounded-3xl border bg-white shadow-sm">
      {product.image && (
        <img
          src={product.image}
          alt={product.name}
          className="h-52 w-full object-cover"
        />
      )}

      <div className="space-y-4 p-5">
        <div className="flex items-center justify-between gap-2">
          <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-800">
            {product.category}
          </span>
          <span className="text-xl font-bold">
            {formatCurrencyINR(product.price)}
          </span>
        </div>

        <div>
          <h3 className="text-xl font-bold">{product.name}</h3>
          <p className="mt-2 text-sm text-gray-500">{product.description}</p>
        </div>

        <button
          type="button"
          onClick={() => addToCart(product)}
          className="flex w-full items-center justify-center gap-2 rounded-full bg-green-800 px-4 py-3 text-sm font-semibold text-white hover:bg-green-900"
        >
          <FaShoppingCart />
          Add to Cart
        </button>
      </div>
    </article>
  );
}

export default ProductCard;