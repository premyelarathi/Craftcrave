import { FaFacebookF, FaInstagram, FaPaw, FaTwitter } from 'react-icons/fa'
import { Link } from 'react-router-dom'

const quickLinks = [
  { label: 'About', to: '/about' },
  { label: 'Buy Pets', to: '/pets' },
  { label: 'Pet Care', to: '/pet-care' },
  { label: 'Accessories', to: '/accessories' },
  { label: 'Find Vets', to: '/vets' },
]

const petCategories = [
  { label: 'Dogs', to: '/pets?category=dogs' },
  { label: 'Cats', to: '/pets?category=cats' },
  { label: 'Birds', to: '/pets?category=birds' },
  { label: 'Fish', to: '/pets?category=fish' },
  { label: 'Rabbits', to: '/pets?category=rabbits' },
]

const petCareLinks = [
  { label: 'Nutrition', to: '/pet-care' },
  { label: 'Grooming', to: '/pet-care' },
  { label: 'Training', to: '/pet-care' },
  { label: 'Pet Safety', to: '/pet-care' },
  { label: 'Tracking', to: '/tracking' },
]

const currentYear = new Date().getFullYear()

function Footer() {
  return (
    <footer className="mt-16 bg-slate-900 text-slate-200">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <div className="mb-4 flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-sky-600 text-white">
                <FaPaw />
              </span>
              <span className="text-lg font-bold text-white">Pet Hub</span>
            </div>
            <p className="max-w-sm text-sm text-slate-300">
              Everything your pet needs, all in one place.
            </p>
            <div className="mt-6 flex gap-3">
              {[FaFacebookF, FaInstagram, FaTwitter].map((Icon, index) => (
                <span key={index} className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-700 bg-slate-800 text-sm text-slate-200">
                  <Icon />
                </span>
              ))}
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-[0.15em] text-white">Quick links</h3>
            <ul className="space-y-2 text-sm text-slate-300">
              {quickLinks.map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="transition hover:text-white">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-[0.15em] text-white">Categories</h3>
            <ul className="space-y-2 text-sm text-slate-300">
              {petCategories.map((category) => (
                <li key={category.to}>
                  <Link to={category.to} className="transition hover:text-white">
                    {category.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-[0.15em] text-white">Contact</h3>
            <ul className="space-y-2 text-sm text-slate-300">
              {petCareLinks.map((link) => (
                <li key={link.label}>
                  <Link to={link.to} className="transition hover:text-white">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-4 space-y-2 text-sm text-slate-300">
              <p>hello@pethub.demo</p>
              <p>+91 98XXX XXXXX</p>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-slate-700 pt-4 text-center text-sm text-slate-400">
          © {currentYear} Pet Hub. All rights reserved.
        </div>
      </div>
    </footer>
  )
}

export default Footer
