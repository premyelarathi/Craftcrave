import { Link } from 'react-router-dom'
import { FaMapMarkerAlt, FaPaw } from 'react-icons/fa'
import { formatCurrencyINR } from '../utils/format'

function PetCard({ pet }) {
  return (
    <article className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-sm transition duration-200 hover:-translate-y-1 hover:shadow-lg">
      <div className="space-y-4 p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-xl font-bold text-slate-900">{pet.name}</h3>
            <p className="text-sm text-slate-500">{pet.breed}</p>
          </div>
          <span className="rounded-full bg-[#FFF5E8] px-2.5 py-1 text-xs font-semibold text-slate-700">
            {pet.category}
          </span>
        </div>
        <span
          className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${
            pet.available ? 'bg-slate-100 text-slate-700' : 'bg-[#FDE7DB] text-slate-700'
          }`}
        >
          {pet.available ? 'Available' : 'Reserved'}
        </span>

        <div className="flex items-center justify-between text-sm text-slate-500">
          <span>Age: {pet.age}</span>
          <span>{pet.gender}</span>
        </div>

        <div className="flex items-center gap-2 text-sm text-slate-500">
          <FaMapMarkerAlt className="text-slate-700" />
          <span>{pet.location}</span>
        </div>

        <div className="flex items-center justify-between border-t border-slate-200 pt-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-slate-500">Fee</p>
            <p className="mt-1 text-lg font-bold text-slate-900">{formatCurrencyINR(pet.price)}</p>
          </div>
          <div className="flex gap-2">
            <Link
              to={`/pets/${pet.id}`}
              className="inline-flex items-center rounded-full border border-slate-700 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-700 hover:text-white"
            >
              View Details
            </Link>
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-full bg-slate-700 px-3 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              <FaPaw className="text-xs" />
              Enquire
            </button>
          </div>
        </div>
      </div>
    </article>
  )
}

export default PetCard
