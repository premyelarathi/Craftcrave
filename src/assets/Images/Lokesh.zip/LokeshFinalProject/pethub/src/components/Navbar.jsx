import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { FaBars, FaPaw, FaShoppingCart, FaTimes } from 'react-icons/fa'
import { useCart } from '../hooks/useCart'
const navItems = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  { label: 'Buy Pets', to: '/pets' },
  { label: 'Pet Care', to: '/pet-care' },
  { label: 'Accessories', to: '/accessories' },
  { label: 'Find Vets', to: '/vets' },
  { label: 'Categories', to: '/categories' },
  { label: 'Pet Tracking', to: '/tracking' },
  { label: 'Contact Us', to: '/contact' },
]
function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const { itemCount } = useCart()
  return (
    <header className="site-header">
      <div className="nav-wrap">
        <Link to="/" className="brand" aria-label="Pet Hub home">
          <span className="brand-mark">
            <FaPaw />
          </span>
          <span>Pet Hub</span>
        </Link>
        <nav className="nav-menu">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
              onClick={() => setIsOpen(false)}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="nav-actions">
          <Link to="/cart" className="cart-button" aria-label="Shopping cart">
            <FaShoppingCart />
            {itemCount > 0 && <span className="cart-count">{itemCount}</span>}
          </Link>
          <button
            type="button"
            className="mobile-toggle"
            onClick={() => setIsOpen((value) => !value)}
            aria-label="Toggle menu"
            aria-expanded={isOpen}
            aria-controls="mobile-navigation"
          >
            {isOpen ? <FaTimes /> : <FaBars />}
          </button>
        </div>
      </div>
      {isOpen && (
        <nav className="mobile-nav" id="mobile-navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `mobile-nav-link ${isActive ? 'active' : ''}`}
              onClick={() => setIsOpen(false)}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      )}
    </header>
  )
}
export default Navbar
