function EmptyState({ title, message, action }) {
  return (
    <div className="rounded-3xl border border-dashed border-slate-200 bg-slate-50 p-10 text-center">
      <h3 className="text-xl font-semibold text-slate-900">{title}</h3>
      <p className="mt-3 text-slate-500">{message}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  )
}

export default EmptyState
