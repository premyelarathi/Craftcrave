import { Link } from "react-router-dom";

function ArticleCard({ article }) {
  return (
    <article className="overflow-hidden rounded-3xl border bg-white shadow-sm">
      <img
        src={article.image}
        alt={article.title}
        className="h-48 w-full object-cover"
      />

      <div className="space-y-4 p-5">
        <div className="flex justify-between text-xs font-semibold text-green-800">
          <span>{article.category}</span>
          <span>{article.readTime}</span>
        </div>

        <h3 className="text-xl font-bold">{article.title}</h3>
        <p className="text-sm text-gray-500">{article.description}</p>

        <Link
          to={`/pet-care/${article.id}`}
          className="inline-flex rounded-full bg-green-800 px-4 py-2 text-sm font-medium text-white hover:bg-green-900"
        >
          Read More
        </Link>
      </div>
    </article>
  );
}

export default ArticleCard;