import { Link } from 'react-router-dom'

function CategoryCard({ category }) {
  return (
    <article className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-sm transition duration-200 hover:-translate-y-1 hover:shadow-lg">
      <div className="space-y-4 p-5">
        <h3 className="text-2xl font-bold text-slate-900">{category.name}</h3>
        <p className="text-sm text-slate-500">{category.description}</p>
        <Link
          to={`/pets?category=${category.slug}`}
          className="inline-flex rounded-full bg-slate-700 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
        >
          Explore
        </Link>
      </div>
    </article>
  )
}

export default CategoryCard
