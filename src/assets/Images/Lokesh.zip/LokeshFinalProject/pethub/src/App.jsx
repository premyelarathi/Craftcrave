import './App.css'
import { Route, Routes } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import { CartProvider } from './context/CartContext'
import { PetProvider } from './context/PetContext'
import AboutPage from './pages/AboutPage'
import AccessoriesPage from './pages/AccessoriesPage'
import ArticlePage from './pages/ArticlePage'
import CartPage from './pages/CartPage'
import CategoriesPage from './pages/CategoriesPage'
import ContactPage from './pages/ContactPage'
import HomePage from './pages/HomePage'
import NotFoundPage from './pages/NotFoundPage'
import PetCarePage from './pages/PetCarePage'
import PetDetailsPage from './pages/PetDetailsPage'
import PetsPage from './pages/PetsPage'
import TrackingPage from './pages/TrackingPage'
import VetsPage from './pages/VetsPage'

function AppLayout() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/pets" element={<PetsPage />} />
          <Route path="/pets/:id" element={<PetDetailsPage />} />
          <Route path="/pet-care" element={<PetCarePage />} />
          <Route path="/pet-care/:id" element={<ArticlePage />} />
          <Route path="/accessories" element={<AccessoriesPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/vets" element={<VetsPage />} />
          <Route path="/categories" element={<CategoriesPage />} />
          <Route path="/tracking" element={<TrackingPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}

function App() {
  return (
    <CartProvider>
      <PetProvider>
        <AppLayout />
      </PetProvider>
    </CartProvider>
  )
}

export default App
