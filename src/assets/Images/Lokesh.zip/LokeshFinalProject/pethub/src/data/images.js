import dog from "../assets/dog.png";

import petExercise from "../assets/pet-exercise.jpeg";
import petGrooming from "../assets/pet-grooming.jpeg";
import petTraining from "../assets/pet-training.jpeg";
import petHygiene from "../assets/pet-hygiene.jpeg";

import puppyNutrition from "../assets/puppy-nutrition.jpeg";
import puppyCare from "../assets/puppy-care.jpeg";

import clinic1 from "../assets/et-clinic-1.jpeg";
import clinic2 from "../assets/et-clinic-2.jpeg";
import clinic3 from "../assets/et-clinic-3.jpeg";
import clinic4 from "../assets/et-clinic-4.jpeg";

import shampoo from "../assets/et-shampoo.jpg";
import treatDispenser from "../assets/treat-dispenser.jpg";

export const images = {
  dog,
  petExercise,
  petGrooming,
  petTraining,
  petHygiene,
  puppyNutrition,
  puppyCare,
  clinic1,
  clinic2,
  clinic3,
  clinic4,
  shampoo,
  treatDispenser,
};