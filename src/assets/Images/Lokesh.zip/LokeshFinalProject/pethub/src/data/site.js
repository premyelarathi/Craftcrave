export const WHATSAPP_NUMBER = '';

export const brandName = 'Pet Hub';