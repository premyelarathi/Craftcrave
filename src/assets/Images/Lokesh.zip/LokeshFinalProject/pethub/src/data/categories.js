import { images } from "./images";

export const categories = [
  {
    id: "category-dogs",
    slug: "dogs",
    name: "Dogs",
    description: "Loyal companions for active families and playful homes.",
    image: images.goldenPuppy,
  },
  {
    id: "category-cats",
    slug: "cats",
    name: "Cats",
    description: "Independent, affectionate pets suited for cozy, calm spaces.",
    image: images.kitten,
  },
  {
    id: "category-birds",
    slug: "birds",
    name: "Birds",
    description: "Bright, social companions that bring color and curiosity to a home.",
    image: images.petTraining,
  },
  {
    id: "category-fish",
    slug: "fish",
    name: "Fish",
    description: "A serene choice for modern homes and easy-care aquariums.",
    image: images.petHygiene,
  },
  {
    id: "category-rabbits",
    slug: "rabbits",
    name: "Rabbits",
    description: "Gentle, curious animals that thrive with patient care and space.",
    image: images.rabbit,
  },
  {
    id: "category-hamsters",
    slug: "hamsters",
    name: "Hamsters",
    description: "Small, playful companions that are best for compact spaces.",
    image: images.puppyCare,
  },
];