export const formatCurrencyINR = (amount) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount)

export const getUniqueValues = (items, key) =>
  [...new Set(items.map((item) => item[key]).filter(Boolean))]

export const navigateToMap = (address) =>
  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`
