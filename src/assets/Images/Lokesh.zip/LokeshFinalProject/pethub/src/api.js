const CLIENT_ID_KEY = 'pethub-client-id'

function getClientId() {
  let clientId = localStorage.getItem(CLIENT_ID_KEY)
  if (!clientId) {
    clientId = crypto.randomUUID()
    localStorage.setItem(CLIENT_ID_KEY, clientId)
  }
  return clientId
}

export const clientId = getClientId()

export async function apiRequest(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  })

  let result
  try {
    result = await response.json()
  } catch {
    throw new Error('The API returned an invalid response. Check that the backend is running.')
  }
  if (!response.ok) {
    throw new Error(result.error || 'The request could not be completed.')
  }
  return result
}
