import { Link } from "react-router-dom";

function CategoryCard({ category }) {
  return (
    <article className="overflow-hidden rounded-3xl border border-green-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
      <img
        src={category.image}
        alt={category.name}
        className="h-48 w-full object-cover"
      />

      <div className="space-y-3 p-5">
        <h3 className="text-2xl font-bold text-green-950">
          {category.name}
        </h3>

        <p className="text-sm text-gray-500">
          {category.description}
        </p>

        <Link
          to={`/pets?category=${category.slug}`}
          className="inline-flex rounded-full bg-green-800 px-4 py-2 text-sm font-semibold text-white hover:bg-green-900"
        >
          Explore
        </Link>
      </div>
    </article>
  );
}

export default CategoryCard;