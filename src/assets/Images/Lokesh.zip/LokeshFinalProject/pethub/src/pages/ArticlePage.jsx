import { Link, useParams } from 'react-router-dom'
import { FaArrowLeft } from 'react-icons/fa'
import { articles } from '../data/articles'

function ArticlePage() {
  const { id } = useParams()
  const article = articles.find((item) => item.id === id)

  if (!article) {
    return (
      <div className="rounded-[28px] border border-dashed border-slate-200 bg-slate-50 p-12 text-center">
        <h2 className="text-2xl font-bold text-slate-900">Article not found</h2>
        <Link to="/pet-care" className="mt-5 inline-flex items-center gap-2 rounded-full bg-slate-700 px-5 py-3 text-white">
          <FaArrowLeft />
          Back to pet care
        </Link>
      </div>
    )
  }

  return (
    <div className="space-y-8 pb-12">
      <Link to="/pet-care" className="inline-flex items-center gap-2 text-slate-700 font-medium">
        <FaArrowLeft />
        Back to pet care
      </Link>

      <article className="overflow-hidden rounded-[32px] border border-slate-200 bg-white shadow-sm">
        <div className="space-y-5 p-6 sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs font-semibold uppercase tracking-[0.18em] text-slate-700">
            <span>{article.category}</span>
            <span>{article.readTime}</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900">{article.title}</h1>
          <p className="text-lg text-slate-600">{article.description}</p>
          <div className="rounded-[24px] bg-slate-50 p-5 text-slate-600">
            {article.content}
          </div>
        </div>
      </article>
    </div>
  )
}

export default ArticlePage
