import { useMemo, useState } from 'react'
import EmptyState from '../components/EmptyState'
import SectionHeading from '../components/SectionHeading'
import VetCard from '../components/VetCard'
import { vets } from '../data/vets'

const allServices = ['All', ...new Set(vets.flatMap((vet) => vet.services))]

function VetsPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedService, setSelectedService] = useState('All')

  const filteredVets = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()

    return vets.filter((vet) => {
      const matchesText =
        vet.name.toLowerCase().includes(term) ||
        vet.city.toLowerCase().includes(term) ||
        vet.area.toLowerCase().includes(term) ||
        vet.pin.includes(term) ||
        term === ''

      const matchesService =
        selectedService === 'All' || vet.services.some((service) => service === selectedService)

      return matchesText && matchesService
    })
  }, [searchTerm, selectedService])

  return (
    <div className="space-y-8 pb-12">
      <SectionHeading
        eyebrow="Find vets"
        title="Explore veterinary clinics nearby"
        description="Use city, area, or PIN code search to browse demonstration clinics and their services."
      />

      <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm">
        <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
          <input
            type="text"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Search by city, area, or PIN code"
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          />
          <select
            value={selectedService}
            onChange={(event) => setSelectedService(event.target.value)}
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          >
            {allServices.map((service) => (
              <option key={service} value={service}>
                {service === 'All' ? 'All services' : service}
              </option>
            ))}
          </select>
        </div>
      </div>

      {filteredVets.length === 0 ? (
        <EmptyState
          title="No clinics match your filters"
          message="Try a broader city or service filter to explore more nearby options."
        />
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-2">
          {filteredVets.map((vet) => (
            <VetCard key={vet.id} vet={vet} />
          ))}
        </div>
      )}
    </div>
  )
}

export default VetsPage
