import { Link, useParams } from 'react-router-dom'
import { FaArrowLeft, FaMapMarkerAlt } from 'react-icons/fa'
import { pets } from '../data/pets'
import { formatCurrencyINR } from '../utils/format'

function PetDetailsPage() {
  const { id } = useParams()
  const pet = pets.find((item) => item.id === id)

  if (!pet) {
    return (
      <div className="rounded-3xl border bg-white p-12 text-center">
        <h2 className="text-2xl font-bold text-green-950">Pet not found</h2>
        <Link to="/pets" className="mt-5 inline-flex rounded-full bg-green-800 px-5 py-3 text-white">
          Back to pets
        </Link>
      </div>
    )
  }

  return (
    <div className="space-y-8 pb-12">
      <Link to="/pets" className="inline-flex items-center gap-2 font-medium text-green-800">
        <FaArrowLeft />
        Back to listings
      </Link>

      <div className="overflow-hidden rounded-3xl border border-green-100 bg-white shadow-sm">
        {pet.image && (
          <img
            src={pet.image}
            alt={pet.name}
            className="h-72 w-full object-cover sm:h-96"
          />
        )}

        <div className="space-y-6 p-6 sm:p-8">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase text-green-700">{pet.category}</p>
              <h1 className="mt-2 text-4xl font-black text-green-950">{pet.name}</h1>
            </div>
            <span className="rounded-full bg-green-50 px-3 py-2 text-xs font-semibold text-green-800">
              {pet.available ? 'Available' : 'Reserved'}
            </span>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {[
              ['Breed', pet.breed],
              ['Age', pet.age],
              ['Gender', pet.gender],
              ['Price', formatCurrencyINR(pet.price)],
            ].map(([label, value]) => (
              <div key={label} className="rounded-2xl bg-green-50 p-4">
                <p className="text-xs uppercase text-gray-500">{label}</p>
                <p className="mt-2 text-lg font-bold text-green-950">{value}</p>
              </div>
            ))}
          </div>

          <p className="flex items-center gap-2 text-sm text-gray-500">
            <FaMapMarkerAlt className="text-green-800" />
            {pet.location}
          </p>

          <p className="text-gray-600">{pet.description}</p>

          <a
            href={`https://wa.me/?text=${encodeURIComponent(`Hello, I am interested in ${pet.name}.`)}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex rounded-full bg-green-800 px-6 py-3 font-semibold text-white hover:bg-green-900"
          >
            Enquire Now
          </a>
        </div>
      </div>

      <section className="rounded-3xl border border-green-100 bg-white p-7 shadow-sm">
        <h2 className="text-2xl font-bold text-green-950">Care Overview</h2>
        <p className="mt-4 text-gray-600">{pet.care}</p>
      </section>
    </div>
  )
}

export default PetDetailsPage