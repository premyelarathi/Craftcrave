import { useMemo, useState } from 'react'
import ArticleCard from '../components/ArticleCard'
import EmptyState from '../components/EmptyState'
import SectionHeading from '../components/SectionHeading'
import { articles } from '../data/articles'

const filters = ['All', 'Nutrition', 'Grooming', 'Hygiene', 'Exercise', 'Training', 'Puppy care']

function PetCarePage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedFilter, setSelectedFilter] = useState('All')

  const filteredArticles = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()

    return articles.filter((article) => {
      const matchesSearch =
        article.title.toLowerCase().includes(term) ||
        article.description.toLowerCase().includes(term) ||
        term === ''
      const matchesCategory = selectedFilter === 'All' || article.category === selectedFilter
      return matchesSearch && matchesCategory
    })
  }, [searchTerm, selectedFilter])

  return (
    <div className="space-y-8 pb-12">
      <SectionHeading
        eyebrow="Pet care library"
        title="Helpful knowledge for happier routines"
        description="Browse practical care guidance and learn the basics of pet wellness, safety, and familiar daily habits."
      />

      <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
          <input
            type="text"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Search articles or topics"
            className="w-full rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          />
          <select
            value={selectedFilter}
            onChange={(event) => setSelectedFilter(event.target.value)}
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          >
            {filters.map((filter) => (
              <option key={filter} value={filter}>
                {filter}
              </option>
            ))}
          </select>
        </div>
      </div>

      {filteredArticles.length === 0 ? (
        <EmptyState
          title="No articles match your search"
          message="Try another keyword or switch to a broader care category."
        />
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {filteredArticles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  )
}

export default PetCarePage
