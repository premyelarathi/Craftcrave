import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import EmptyState from '../components/EmptyState'
import PetCard from '../components/PetCard'
import SectionHeading from '../components/SectionHeading'
import { pets, petCategories } from '../data/pets'

const allCategories = ['all', ...petCategories]

function PetsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const initialCategory = searchParams.get('category') || 'all'

  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState(initialCategory)
  const [sortBy, setSortBy] = useState('featured')

  const filteredPets = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()

    const results = pets.filter((pet) => {
      const matchesText =
        pet.name.toLowerCase().includes(term) ||
        pet.breed.toLowerCase().includes(term) ||
        term === ''

      const matchesCategory = selectedCategory === 'all' || pet.category === selectedCategory

      return matchesText && matchesCategory
    })

    return results.sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price
      if (sortBy === 'price-high') return b.price - a.price
      if (sortBy === 'age') return a.age.localeCompare(b.age)
      return 0
    })
  }, [searchTerm, selectedCategory, sortBy])

  const applyCategory = (value) => {
    setSelectedCategory(value)
    if (value === 'all') {
      searchParams.delete('category')
      setSearchParams(searchParams)
      return
    }

    setSearchParams({ category: value })
  }

  const clearFilters = () => {
    setSearchTerm('')
    setSelectedCategory('all')
    setSortBy('featured')
    setSearchParams({})
  }

  return (
    <div className="space-y-8 pb-12">
      <SectionHeading
        eyebrow="Pet discovery"
        title="Find your perfect companion"
        description="Use smart search, category filters, and pricing options to browse the most suitable matches."
      />

      <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm">
        <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr_1fr_auto]">
          <input
            type="text"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Search by pet name or breed"
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none ring-0 transition focus:border-slate-700"
          />

          <select
            value={selectedCategory}
            onChange={(event) => applyCategory(event.target.value)}
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          >
            {allCategories.map((category) => (
              <option key={category} value={category}>
                {category === 'all' ? 'All categories' : category}
              </option>
            ))}
          </select>

          <select
            value={sortBy}
            onChange={(event) => setSortBy(event.target.value)}
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          >
            <option value="featured">Featured</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="age">Age</option>
          </select>

          <button
            type="button"
            onClick={clearFilters}
            className="rounded-full border border-slate-700 px-4 py-3 font-medium text-slate-700 transition hover:bg-slate-700 hover:text-white"
          >
            Clear filters
          </button>
        </div>
      </div>

      <div className="flex items-center justify-between text-sm text-slate-500">
        <p>{filteredPets.length} results</p>
      </div>

      {filteredPets.length === 0 ? (
        <EmptyState
          title="No pets match your search"
          message="Try a different breed, category, or keyword to broaden the results."
          action={
            <button
              type="button"
              onClick={clearFilters}
              className="rounded-full bg-slate-700 px-5 py-3 font-medium text-white transition hover:bg-slate-800"
            >
              Reset filters
            </button>
          }
        />
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {filteredPets.map((pet) => (
            <PetCard key={pet.id} pet={pet} />
          ))}
        </div>
      )}
    </div>
  )
}

export default PetsPage
