import SectionHeading from '../components/SectionHeading'

const responsibilities = [
  {
    title: 'Choosing a suitable companion',
    text: 'Every pet has a temperament, routine, and living requirement. Matching the right companion to your lifestyle matters most.',
  },
  {
    title: 'Understanding animal needs',
    text: 'Nutrition, rest, enrichment, and social care all influence how healthy and content a pet feels at home.',
  },
  {
    title: 'Adoption with care',
    text: 'Responsible pet ownership starts with adoption decisions that prioritise welfare, stability, and long-term commitment.',
  },
]

const overview = [
  'Pet ownership is a long-term responsibility involving time, care, and attention.',
  'A good match supports a calmer home and a healthier emotional connection for both pet and family.',
  'Pet Hub exists to make research and preparation easier for new and current pet parents.',
]

function AboutPage() {
  return (
    <div className="space-y-12 pb-12">
      <section className="rounded-[32px] bg-slate-100 p-8 sm:p-10">
        <SectionHeading
          eyebrow="About Pet Hub"
          title="A caring platform for better pet ownership"
          description="We believe pet care starts with understanding. From companion selection to daily routines, thoughtful choices create happier homes."
        />
      </section>

      <section className="grid gap-6 md:grid-cols-3">
        {responsibilities.map((item) => (
          <div key={item.title} className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-slate-700 text-lg font-bold text-white">
              0{responsibilities.indexOf(item) + 1}
            </div>
            <h3 className="text-xl font-bold text-slate-900">{item.title}</h3>
            <p className="mt-3 text-sm text-slate-500">{item.text}</p>
          </div>
        ))}
      </section>

      <section className="grid gap-8 lg:grid-cols-2">
        <div className="rounded-[28px] border border-slate-200 bg-white p-7 shadow-sm">
          <h3 className="text-2xl font-bold text-slate-900">Why responsible pet ownership matters</h3>
          <ul className="mt-5 space-y-4 text-slate-600">
            {overview.map((point) => (
              <li key={point} className="flex gap-3">
                <span className="mt-1 inline-flex h-5 w-5 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-700">
                  ✓
                </span>
                <span>{point}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-[28px] border border-slate-200 bg-white p-7 shadow-sm">
          <h3 className="text-2xl font-bold text-slate-900">Purpose of Pet Hub</h3>
          <p className="mt-4 text-slate-600">
            Pet Hub helps families explore suitable animals, learn daily care essentials, compare trusted vets, and build a more informed relationship with their pets. It blends discovery, education, and practical pet support in one friendly experience.
          </p>
          <div className="mt-6 rounded-[22px] bg-slate-50 p-5">
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-slate-700">Our mission</p>
            <p className="mt-2 text-slate-600">
              To make pet care approachable, transparent, and supportive for every stage of the journey.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}

export default AboutPage
