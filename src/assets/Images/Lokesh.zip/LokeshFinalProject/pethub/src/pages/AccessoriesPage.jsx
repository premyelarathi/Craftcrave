import { useMemo, useState } from 'react'
import EmptyState from '../components/EmptyState'
import ProductCard from '../components/ProductCard'
import SectionHeading from '../components/SectionHeading'
import { products } from '../data/products'

const categories = ['All', ...new Set(products.map((product) => product.category))]

function AccessoriesPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [sortBy, setSortBy] = useState('featured')

  const filteredProducts = useMemo(() => {
    const term = searchTerm.trim().toLowerCase()

    const results = products.filter((product) => {
      const matchesSearch =
        product.name.toLowerCase().includes(term) ||
        product.description.toLowerCase().includes(term) ||
        term === ''
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory
      return matchesSearch && matchesCategory
    })

    return results.sort((a, b) => {
      if (sortBy === 'low-high') return a.price - b.price
      if (sortBy === 'high-low') return b.price - a.price
      return 0
    })
  }, [searchTerm, selectedCategory, sortBy])

  return (
    <div className="space-y-8 pb-12">
      <SectionHeading
        eyebrow="Accessories"
        title="Pet essentials for daily life"
        description="Choose the right feeding, travel, grooming, and comfort items for your daily care routine."
      />

      <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm">
        <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr_1fr]">
          <input
            type="text"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Search products"
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          />
          <select
            value={selectedCategory}
            onChange={(event) => setSelectedCategory(event.target.value)}
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category === 'All' ? 'All categories' : category}
              </option>
            ))}
          </select>
          <select
            value={sortBy}
            onChange={(event) => setSortBy(event.target.value)}
            className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none transition focus:border-slate-700"
          >
            <option value="featured">Featured</option>
            <option value="low-high">Price: Low to High</option>
            <option value="high-low">Price: High to Low</option>
          </select>
        </div>
      </div>

      {filteredProducts.length === 0 ? (
        <EmptyState
          title="No accessories match your filters"
          message="Try adjusting the category or price sort to find a better match."
        />
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}

export default AccessoriesPage
