import { useState } from 'react'
import { FaEnvelope, FaMapMarkerAlt, FaPhoneAlt, FaWhatsapp } from 'react-icons/fa'
import SectionHeading from '../components/SectionHeading'
import { WHATSAPP_NUMBER } from '../data/site'
import { apiRequest } from '../api'

const initialForm = {
  name: '',
  email: '',
  subject: '',
  message: '',
}

function ContactPage() {
  const [formData, setFormData] = useState(initialForm)
  const [errors, setErrors] = useState({})
  const [successMessage, setSuccessMessage] = useState('')
  const [requestError, setRequestError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (event) => {
    const { name, value } = event.target
    setFormData((current) => ({ ...current, [name]: value }))
  }

  const validateForm = () => {
    const nextErrors = {}

    if (!formData.name.trim()) nextErrors.name = 'Name is required.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) nextErrors.email = 'Valid email is required.'
    if (!formData.subject.trim()) nextErrors.subject = 'Subject is required.'
    if (!formData.message.trim() || formData.message.trim().length < 10) {
      nextErrors.message = 'Please include a short but clear message.'
    }

    setErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    if (!validateForm()) {
      setSuccessMessage('')
      return
    }

    setIsSubmitting(true)
    setRequestError('')
    try {
      const result = await apiRequest('/contact', {
        method: 'POST',
        body: JSON.stringify(formData),
      })
      setSuccessMessage(result.message)
      setFormData(initialForm)
      setErrors({})
    } catch (error) {
      setRequestError(error.message)
      setSuccessMessage('')
    } finally {
      setIsSubmitting(false)
    }
  }

  const whatsappNumber = WHATSAPP_NUMBER.trim()
  const whatsappUrl = whatsappNumber
    ? `https://wa.me/${whatsappNumber}?text=${encodeURIComponent('Hello Pet Hub, I would like to enquire about your demo services.')}`
    : null

  return (
    <div className="space-y-8 pb-12">
      <SectionHeading
        eyebrow="Contact us"
        title="We are here to help"
        description="Reach out with feedback, enquiries, or questions. Valid messages are saved to the Pet Hub database."
      />

      <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr]">
        <div className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-2xl font-bold text-slate-900">Contact details</h3>
          <div className="mt-6 space-y-4 text-slate-600">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-700">
                <FaEnvelope />
              </span>
              <span>hello@pethub.demo</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-700">
                <FaPhoneAlt />
              </span>
              <span>+91 98XXX XXXXX</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-700">
                <FaMapMarkerAlt />
              </span>
              <span>Demo office, Bengaluru</span>
            </div>
          </div>

          <div className="mt-6">
            {whatsappUrl ? (
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-sky-500 px-5 py-3 font-semibold text-white"
              >
                <FaWhatsapp />
                WhatsApp enquiry
              </a>
            ) : (
              <p className="rounded-[20px] bg-slate-50 p-4 text-sm text-slate-500">
                WhatsApp number not configured. Add a valid number in the frontend setup to enable the link.
              </p>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <label htmlFor="contact-name" className="text-sm font-medium text-slate-900">Name</label>
              <input id="contact-name" name="name" value={formData.name} onChange={handleChange} required className="w-full rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
              {errors.name && <p className="text-sm text-slate-700">{errors.name}</p>}
            </div>
            <div className="space-y-2">
              <label htmlFor="contact-email" className="text-sm font-medium text-slate-900">Email</label>
              <input id="contact-email" name="email" type="email" value={formData.email} onChange={handleChange} required className="w-full rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
              {errors.email && <p className="text-sm text-slate-700">{errors.email}</p>}
            </div>
            <div className="space-y-2 md:col-span-2">
              <label htmlFor="contact-subject" className="text-sm font-medium text-slate-900">Subject</label>
              <input id="contact-subject" name="subject" value={formData.subject} onChange={handleChange} required className="w-full rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
              {errors.subject && <p className="text-sm text-slate-700">{errors.subject}</p>}
            </div>
            <div className="space-y-2 md:col-span-2">
              <label htmlFor="contact-message" className="text-sm font-medium text-slate-900">Message</label>
              <textarea id="contact-message" name="message" rows="5" value={formData.message} onChange={handleChange} required className="w-full rounded-[24px] border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
              {errors.message && <p className="text-sm text-slate-700">{errors.message}</p>}
            </div>
          </div>

          {successMessage && (
            <div className="mt-5 rounded-[20px] bg-slate-100 p-4 text-sm font-medium text-slate-700">
              {successMessage}
            </div>
          )}

          {requestError && <p role="alert" className="mt-5 rounded-[20px] bg-[#FDE7DB] p-4 text-sm text-slate-900">{requestError}</p>}

          <button type="submit" disabled={isSubmitting} className="mt-5 rounded-full bg-slate-700 px-5 py-3 font-semibold text-white hover:bg-slate-800 disabled:opacity-60">
            {isSubmitting ? 'Sending...' : 'Submit request'}
          </button>
        </form>
      </div>
    </div>
  )
}

export default ContactPage
