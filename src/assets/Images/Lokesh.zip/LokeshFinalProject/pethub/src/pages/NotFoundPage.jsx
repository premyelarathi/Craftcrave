import { Link } from 'react-router-dom'

function NotFoundPage() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <div className="rounded-[32px] border border-slate-200 bg-white p-10 text-center shadow-sm">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-700">404</p>
        <h1 className="mt-3 text-4xl font-black text-slate-900">Page not found</h1>
        <p className="mt-3 text-slate-500">The page you are looking for does not exist or has moved.</p>
        <Link to="/" className="mt-6 inline-flex rounded-full bg-slate-700 px-5 py-3 font-semibold text-white hover:bg-slate-800">
          Go home
        </Link>
      </div>
    </div>
  )
}

export default NotFoundPage
