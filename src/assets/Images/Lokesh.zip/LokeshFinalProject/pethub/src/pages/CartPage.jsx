import { FaMinus, FaPaw, FaPlus, FaTrash } from 'react-icons/fa'
import { Link } from 'react-router-dom'
import EmptyState from '../components/EmptyState'
import { useCart } from '../hooks/useCart'
import { formatCurrencyINR } from '../utils/format'

function CartPage() {
  const { items, subtotal, updateQuantity, removeFromCart, clearCart, error } = useCart()

  if (items.length === 0) {
    return (
      <div className="pb-12">
        <EmptyState
          title="Your cart is empty"
          message={error || 'Add a few pet essentials to build your cart and review your total.'}
          action={
            <Link to="/accessories" className="inline-flex rounded-full bg-slate-700 px-5 py-3 font-medium text-white hover:bg-slate-800">
              Explore accessories
            </Link>
          }
        />
      </div>
    )
  }

  return (
    <div className="grid gap-8 pb-12 xl:grid-cols-[1.4fr_0.6fr]">
      {error && <p role="alert" className="rounded-2xl bg-[#FDE7DB] p-4 text-slate-900 xl:col-span-2">{error}</p>}
      <div className="space-y-4">
        {items.map((item) => (
          <div key={item.id} className="flex flex-col gap-4 rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-center">
            <div className="flex h-28 w-full items-center justify-center rounded-[20px] bg-slate-100 text-3xl text-slate-700 sm:w-28" aria-hidden="true">
              <FaPaw />
            </div>
            <div className="flex-1">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 className="text-xl font-bold text-slate-900">{item.name}</h3>
                  <p className="text-sm text-slate-500">{item.category}</p>
                </div>
                <p className="text-lg font-bold text-slate-900">{formatCurrencyINR(item.price * item.quantity)}</p>
              </div>
              <div className="mt-4 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 rounded-full border border-slate-200 bg-white p-1">
                  <button type="button" aria-label={`Decrease ${item.name} quantity`} className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-700" onClick={() => updateQuantity(item.id, -1)}>
                    <FaMinus />
                  </button>
                  <span className="w-8 text-center text-sm font-semibold text-slate-900">{item.quantity}</span>
                  <button type="button" aria-label={`Increase ${item.name} quantity`} className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-700" onClick={() => updateQuantity(item.id, 1)}>
                    <FaPlus />
                  </button>
                </div>
                <button type="button" aria-label={`Remove ${item.name}`} onClick={() => removeFromCart(item.id)} className="inline-flex items-center gap-2 text-sm font-medium text-slate-700">
                  <FaTrash />
                  Remove
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <aside className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-2xl font-bold text-slate-900">Cart summary</h2>
        <div className="mt-6 space-y-4 text-slate-600">
          <div className="flex items-center justify-between">
            <span>Subtotal</span>
            <span className="font-semibold text-slate-900">{formatCurrencyINR(subtotal)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Shipping</span>
            <span className="font-semibold text-slate-900">Free</span>
          </div>
          <div className="flex items-center justify-between border-t border-slate-200 pt-4 text-lg font-bold text-slate-900">
            <span>Total</span>
            <span>{formatCurrencyINR(subtotal)}</span>
          </div>
        </div>

        <button type="button" className="mt-6 w-full rounded-full bg-slate-700 px-5 py-3 font-semibold text-white hover:bg-slate-800">
          Proceed to checkout
        </button>
        <button type="button" onClick={clearCart} className="mt-4 w-full rounded-full border border-slate-700 px-5 py-3 font-semibold text-slate-700 hover:bg-slate-700 hover:text-white">
          Clear cart
        </button>
      </aside>
    </div>
  )
}

export default CartPage
