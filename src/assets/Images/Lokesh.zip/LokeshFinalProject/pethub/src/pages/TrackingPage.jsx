import { useState } from 'react'
import { FaCheck, FaPencilAlt, FaPlus, FaTrash } from 'react-icons/fa'
import EmptyState from '../components/EmptyState'
import { usePetContext } from '../hooks/usePetContext'

const emptyForm = {
  name: '',
  breed: '',
  age: '',
  petId: '',
  vaccinationStatus: '',
  nextAppointment: '',
  lostPetStatus: '',
}

function TrackingPage() {
  const { trackedPets, error, addPet, updatePet, deletePet, addVaccinationRecord, addReminder, toggleReminder } = usePetContext()
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [formData, setFormData] = useState(emptyForm)
  const [vaccinationDraft, setVaccinationDraft] = useState('')
  const [reminderDraft, setReminderDraft] = useState('')

  const handleInputChange = (event) => {
    const { name, value } = event.target
    setFormData((current) => ({ ...current, [name]: value }))
  }

  const handleSubmit = (event) => {
    event.preventDefault()

    const existingPet = trackedPets.find((pet) => pet.id === editingId)
    const payload = {
      ...formData,
      vaccinationStatus: formData.vaccinationStatus || 'Current',
      nextAppointment: formData.nextAppointment || 'Next review soon',
      lostPetStatus: formData.lostPetStatus || 'Safe at home',
      recentActivity: existingPet?.recentActivity || 'Profile added to tracking dashboard',
      reminders: existingPet?.reminders || [],
    }

    if (editingId) {
      updatePet(editingId, payload)
    } else {
      addPet(payload)
    }

    setFormData(emptyForm)
    setEditingId(null)
    setShowForm(false)
  }

  const handleEdit = (pet) => {
    setFormData({
      name: pet.name,
      breed: pet.breed,
      age: pet.age,
      petId: pet.petId,
      vaccinationStatus: pet.vaccinationStatus,
      nextAppointment: pet.nextAppointment,
      lostPetStatus: pet.lostPetStatus,
    })
    setEditingId(pet.id)
    setShowForm(true)
  }

  const handleDelete = (petId) => {
    if (window.confirm('Delete this pet profile?')) {
      deletePet(petId)
    }
  }

  const handleAddVaccination = (petId) => {
    if (!vaccinationDraft.trim()) return
    addVaccinationRecord(petId, vaccinationDraft.trim())
    setVaccinationDraft('')
  }

  const handleAddReminder = (petId) => {
    if (!reminderDraft.trim()) return
    addReminder(petId, reminderDraft.trim())
    setReminderDraft('')
  }

  return (
    <div className="tracking-page space-y-8 pb-12">
      <div className="tracking-page-heading flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-slate-700">Pet tracking</p>
          <h1 className="text-3xl font-bold text-slate-900 sm:text-4xl">Your pet care dashboard</h1>
          <p className="mt-3 max-w-2xl text-slate-500">Keep pet profiles, vaccination updates, and care reminders together. Changes are saved to the database.</p>
        </div>
        <button
          type="button"
          onClick={() => {
            setShowForm((value) => !value)
            setEditingId(null)
            setFormData(emptyForm)
          }}
          className="inline-flex items-center gap-2 rounded-full bg-slate-700 px-5 py-3 font-semibold text-white hover:bg-slate-800"
        >
          <FaPlus />
          Add Pet
        </button>
      </div>

      {error && <p role="alert" className="rounded-2xl bg-[#FDE7DB] p-4 text-slate-900">{error}</p>}

      {showForm && (
        <form onSubmit={handleSubmit} className="tracking-form rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="mb-5 text-xl font-bold text-slate-900">{editingId ? 'Edit pet profile' : 'Add a pet profile'}</h2>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <input name="name" value={formData.name} onChange={handleInputChange} placeholder="Pet name" required className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
            <input name="breed" value={formData.breed} onChange={handleInputChange} placeholder="Breed" required className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
            <input name="age" value={formData.age} onChange={handleInputChange} placeholder="Age" required className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
            <input name="petId" value={formData.petId} onChange={handleInputChange} placeholder="Pet ID" required className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
            <input name="vaccinationStatus" value={formData.vaccinationStatus} onChange={handleInputChange} placeholder="Vaccination status" className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
            <input name="nextAppointment" value={formData.nextAppointment} onChange={handleInputChange} placeholder="Next appointment" className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700" />
            <input name="lostPetStatus" value={formData.lostPetStatus} onChange={handleInputChange} placeholder="Lost-pet status" className="rounded-full border border-slate-200 bg-white px-4 py-3 outline-none focus:border-slate-700 md:col-span-2 xl:col-span-2" />
          </div>
          <div className="mt-5 flex justify-end gap-3">
            <button type="button" onClick={() => setShowForm(false)} className="rounded-full border border-slate-700 px-5 py-3 font-medium text-slate-700">
              Cancel
            </button>
            <button type="submit" className="rounded-full bg-slate-700 px-5 py-3 font-medium text-white hover:bg-slate-800">
              {editingId ? 'Save changes' : 'Add pet'}
            </button>
          </div>
        </form>
      )}

      {trackedPets.length === 0 ? (
        <EmptyState
          title="No pet profiles yet"
          message="Add a pet to start tracking care updates and reminders."
        />
      ) : (
        <div className="tracking-grid grid gap-6 xl:grid-cols-2">
          {trackedPets.map((pet) => (
            <article key={pet.id} className="tracking-pet-card overflow-hidden rounded-[30px] border border-slate-200 bg-white shadow-sm">
                <div className="p-5 sm:p-6">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-4">
                      <span className="tracking-avatar" aria-hidden="true">{pet.name.slice(0, 1).toUpperCase()}</span>
                      <div>
                        <h3 className="text-2xl font-bold text-slate-900">{pet.name}</h3>
                        <p className="text-sm text-slate-500">{pet.breed} • {pet.age}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button type="button" onClick={() => handleEdit(pet)} className="rounded-full bg-slate-100 p-2 text-slate-700" aria-label="Edit pet">
                        <FaPencilAlt />
                      </button>
                      <button type="button" onClick={() => handleDelete(pet.id)} className="rounded-full bg-[#FDE7DB] p-2 text-slate-700" aria-label="Delete pet">
                        <FaTrash />
                      </button>
                    </div>
                  </div>

                  <div className="tracking-details-grid mt-5 grid gap-3 sm:grid-cols-2">
                    <div className="tracking-detail rounded-2xl bg-slate-50 p-3">
                      <p className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Pet ID</p>
                      <p className="mt-2 font-semibold text-slate-900">{pet.petId}</p>
                    </div>
                    <div className="tracking-detail rounded-2xl bg-slate-50 p-3">
                      <p className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Next appointment</p>
                      <p className="mt-2 font-semibold text-slate-900">{pet.nextAppointment}</p>
                    </div>
                    <div className="tracking-detail rounded-2xl bg-slate-50 p-3 sm:col-span-2">
                      <p className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Vaccination</p>
                      <p className="mt-2 font-semibold text-slate-900">{pet.vaccinationStatus}</p>
                    </div>
                  </div>

                  <div className="tracking-activity mt-5">
                    <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-700">Recent activity</p>
                    <p className="mt-2 text-slate-600">{pet.recentActivity}</p>
                  </div>

                  <div className="tracking-vaccine-form mt-5 rounded-[22px] bg-slate-50 p-4">
                    <div className="flex gap-2">
                      <input
                        value={vaccinationDraft}
                        onChange={(event) => setVaccinationDraft(event.target.value)}
                        placeholder="Add vaccination record"
                        className="w-full rounded-full border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-700"
                      />
                      <button type="button" onClick={() => handleAddVaccination(pet.id)} className="rounded-full bg-slate-700 px-3 py-2 text-sm font-medium text-white">
                        Add
                      </button>
                    </div>
                  </div>

                  <div className="tracking-reminders mt-5">
                    <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-700">Reminders</p>
                    <div className="mt-3 space-y-2">
                      {pet.reminders.map((reminder) => (
                        <div key={reminder.id} className="flex items-center justify-between gap-2 rounded-2xl border border-slate-200 p-3">
                          <div className="flex items-center gap-3">
                            <button type="button" onClick={() => toggleReminder(pet.id, reminder.id)} className={`flex h-5 w-5 items-center justify-center rounded-full border ${reminder.done ? 'bg-slate-700 border-slate-700 text-white' : 'border-slate-700 bg-white text-transparent'}`}>
                              {reminder.done && <FaCheck />}
                            </button>
                            <span className={reminder.done ? 'line-through text-slate-500' : 'text-slate-900'}>{reminder.text}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-3 flex gap-2">
                      <input
                        value={reminderDraft}
                        onChange={(event) => setReminderDraft(event.target.value)}
                        placeholder="Add reminder"
                        className="w-full rounded-full border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-700"
                      />
                      <button type="button" onClick={() => handleAddReminder(pet.id)} className="rounded-full bg-slate-700 px-3 py-2 text-sm font-medium text-white">
                        Save
                      </button>
                    </div>
                  </div>
                </div>
            </article>
          ))}
        </div>
      )}
    </div>
  )
}

export default TrackingPage
