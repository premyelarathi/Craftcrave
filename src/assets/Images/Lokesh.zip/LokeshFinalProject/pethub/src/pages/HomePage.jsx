import { Link } from 'react-router-dom'
import { FaArrowRight, FaCheckCircle, FaHeart, FaMapMarkerAlt, FaShieldAlt, FaStethoscope } from 'react-icons/fa'
import ArticleCard from '../components/ArticleCard'
import CategoryCard from '../components/CategoryCard'
import PetCard from '../components/PetCard'
import ProductCard from '../components/ProductCard'
import SectionHeading from '../components/SectionHeading'
import VetCard from '../components/VetCard'
import { articles } from '../data/articles'
import { categories } from '../data/categories'
import { pets } from '../data/pets'
import { products } from '../data/products'
import { vets } from '../data/vets'
import { images } from '../data/images'
const serviceBenefits = [
  { icon: FaShieldAlt, title: 'Trusted care', text: 'Guidance and essentials chosen for real pet lifestyles.' },
  { icon: FaHeart, title: 'Pet-first selection', text: 'Thoughtful picks for comfort, safety, and wellbeing.' },
  { icon: FaStethoscope, title: 'Expert guidance', text: 'Helpful tips from a caring, modern pet-care perspective.' },
]

const testimonials = [
  { name: 'Aisha', text: 'Pet Hub made finding a suitable companion and the right care routine feel easy and personal.' },
  { name: 'Rohan', text: 'The accessories and vet discovery sections are genuinely useful for a busy pet parent.' },
  { name: 'Meera', text: 'I love how clean and friendly the layout feels while still being practical to browse.' },
]

function HomePage() {
  return (
    <div className="space-y-14 pb-10">
      <section className="grid items-center gap-8 overflow-hidden rounded-[32px] bg-green-50 px-5 py-10 sm:px-8 lg:grid-cols-2 lg:px-12">
  <div>
    <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white px-3 py-2 text-sm font-medium text-green-800 shadow-sm">
      <FaCheckCircle />
      Trusted by happy pet parents
    </div>

    <h1 className="max-w-xl text-4xl font-black leading-tight text-green-950 sm:text-5xl lg:text-6xl">
      Find Your Perfect Companion
    </h1>

    <p className="mt-5 max-w-xl text-lg text-gray-600">
      Discover pets, explore expert care tips, find trusted veterinary services, and give your furry friends the love they deserve.
    </p>

    <div className="mt-8 flex flex-wrap gap-4">
      <Link
        to="/pets"
        className="inline-flex items-center gap-2 rounded-full bg-green-800 px-5 py-3 font-semibold text-white hover:bg-green-900"
      >
        Explore Pets
        <FaArrowRight />
      </Link>

      <Link
        to="/pet-care"
        className="inline-flex items-center gap-2 rounded-full border border-green-800 bg-white px-5 py-3 font-semibold text-green-800 hover:bg-green-800 hover:text-white"
      >
        Discover Pet Care
      </Link>
    </div>
  </div>

  <img
    src={images.goldenPuppy}
    alt="Golden Retriever puppy"
    className="h-72 w-full rounded-3xl object-cover sm:h-96"
  />
</section>

      <section className="grid gap-5 md:grid-cols-3">
        {serviceBenefits.map(({ icon: Icon, title, text }) => (
          <div key={title} className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
            <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-700">
              <Icon />
            </span>
            <h3 className="text-xl font-bold text-slate-900">{title}</h3>
            <p className="mt-2 text-sm text-slate-500">{text}</p>
          </div>
        ))}
      </section>

      <section>
        <SectionHeading
          eyebrow="Browse by type"
          title="Popular pet categories"
          description="From playful pups to calm companions, discover the care style that suits your home."
        />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {categories.slice(0, 6).map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading
          eyebrow="Featured companions"
          title="Meet pets ready for a new home"
          description="Each listing is sample demonstration data intended for front-end review and browsing."
        />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {pets.slice(0, 3).map((pet) => (
            <PetCard key={pet.id} pet={pet} />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading
          eyebrow="Essentials"
          title="Popular accessories"
          description="Thoughtful products that keep everyday routines comfortable, clean, and enjoyable."
        />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {products.slice(0, 3).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="rounded-[32px] bg-slate-100 px-5 py-12 sm:px-8">
        <SectionHeading
          eyebrow="Why Pet Hub"
          title="Everything your pet needs, all in one place"
          description="A friendly ecosystem built for discovering companions, shopping thoughtfully, and caring confidently."
        />
        <div className="grid gap-6 md:grid-cols-3">
          {[
            'Explore a curated selection of companion pets',
            'Find pet-care articles tailored to real routines',
            'Track reminders, appointments, and personal pet details',
          ].map((item) => (
            <div key={item} className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-slate-700 text-white">
                <FaCheckCircle />
              </div>
              <p className="text-base font-medium text-slate-900">{item}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeading
          eyebrow="Helpful reads"
          title="Pet-care tips and articles"
          description="Simple, practical advice for healthy routines and gentle care decisions."
        />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {articles.slice(0, 3).map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading
          eyebrow="Nearby support"
          title="Find nearby veterinarians"
          description="Browse demonstration veterinary clinics and service categories for a thoughtful first step."
        />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-2">
          {vets.slice(0, 2).map((vet) => (
            <VetCard key={vet.id} vet={vet} />
          ))}
        </div>
      </section>

      <section className="rounded-[32px] bg-slate-50 p-5 ring-1 ring-slate-200 sm:p-8">
        <div className="grid items-center gap-8 lg:grid-cols-[1fr_1.1fr]">
          <div>
            <SectionHeading
              eyebrow="Pet tracking preview"
              title="Keep your pet details in one dashboard"
              description="Save pet profiles, care reminders, vaccination status, and activity notes in one place."
            />
            <Link to="/tracking" className="mt-4 inline-flex items-center gap-2 rounded-full bg-slate-700 px-5 py-3 font-semibold text-white transition hover:bg-slate-800">
              Open pet tracker
              <FaArrowRight />
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              { label: 'Vaccination status', value: 'Up to date' },
              { label: 'Next reminder', value: '12 Oct 2026' },
              { label: 'Pet profile ID', value: 'PH-1001' },
              { label: 'Lost-pet status', value: 'Safe at home' },
            ].map((stat) => (
              <div key={stat.label} className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
                <p className="text-sm text-slate-500">{stat.label}</p>
                <p className="mt-3 text-2xl font-bold text-slate-900">{stat.value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section>
        <SectionHeading
          eyebrow="Testimonials"
          title="Loved by modern pet families"
          description="Fictional demo feedback used for the project review experience."
          align="center"
        />
        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((item) => (
            <div key={item.name} className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm text-center">
              <FaMapMarkerAlt className="mx-auto mb-4 text-sky-300" />
              <p className="text-base text-slate-600">“{item.text}”</p>
              <p className="mt-5 text-lg font-semibold text-slate-900">{item.name}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-[32px] bg-slate-700 p-8 text-center text-white sm:p-12">
        <h2 className="text-3xl font-bold sm:text-4xl">Ready to welcome a happy pet into your life?</h2>
        <p className="mx-auto mt-4 max-w-2xl text-base text-[#e2e8f0]">
          Explore the best-fitting companion, get care advice, and build a smarter routine with compassion and confidence.
        </p>
        <Link
          to="/pets"
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-sky-400 px-5 py-3 font-semibold text-[#1e293b] transition hover:bg-sky-500"
        >
          Start your search
          <FaArrowRight />
        </Link>
      </section>
    </div>
  )
}

export default HomePage
