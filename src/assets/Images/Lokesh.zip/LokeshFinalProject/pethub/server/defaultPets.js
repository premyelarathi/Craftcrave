export const defaultTrackedPets = [
  {
    id: 'tracked-1',
    name: 'Luna',
    breed: 'Golden Retriever',
    age: '10 months',
    petId: 'PH-1001',
    vaccinationStatus: 'Up to date',
    nextAppointment: '12 Oct 2026',
    recentActivity: 'Enjoyed a long walk in Cubbon Park',
    reminders: [
      { id: 'rem-1', text: 'Deworming due', done: false },
      { id: 'rem-2', text: 'Brush coat before weekend', done: true },
    ],
    lostPetStatus: 'Safe at home',
  },
  {
    id: 'tracked-2',
    name: 'Milo',
    breed: 'Persian Cat',
    age: '8 months',
    petId: 'PH-1002',
    vaccinationStatus: 'Pending booster',
    nextAppointment: '18 Oct 2026',
    recentActivity: 'Showed interest in a new cat tree',
    reminders: [
      { id: 'rem-3', text: 'Vaccination booster check', done: false },
    ],
    lostPetStatus: 'Indoor only',
  },
]
