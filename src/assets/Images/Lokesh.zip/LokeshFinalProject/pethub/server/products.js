export const products = [
  { id: 'prod-1', name: 'Premium Puppy Bowl', category: 'Food', price: 1499 },
  { id: 'prod-2', name: 'Bouncy Rope Toy', category: 'Toys', price: 799 },
  { id: 'prod-3', name: 'Leather Collar Set', category: 'Collars and leashes', price: 1899 },
  { id: 'prod-4', name: 'Cloud Nest Bed', category: 'Beds', price: 3499 },
  { id: 'prod-5', name: 'Grooming Brush Kit', category: 'Grooming', price: 1299 },
  { id: 'prod-6', name: 'Ceramic Feeding Set', category: 'Feeding bowls', price: 1499 },
  { id: 'prod-7', name: 'Travel Pet Carrier', category: 'Carriers', price: 4200 },
  { id: 'prod-8', name: 'Fresh Paw Shampoo', category: 'Hygiene', price: 999 },
  { id: 'prod-9', name: 'Treat Dispenser', category: 'Training supplies', price: 1199 },
]
