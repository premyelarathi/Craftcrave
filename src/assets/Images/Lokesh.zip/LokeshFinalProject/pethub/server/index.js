import cors from 'cors'
import dotenv from 'dotenv'
import express from 'express'
import mongoose from 'mongoose'
import { randomUUID } from 'node:crypto'
import { Cart, ContactMessage, PetProfile } from './models.js'
import { defaultTrackedPets } from './defaultPets.js'
import { products } from './products.js'

dotenv.config()

const app = express()
const port = Number(process.env.PORT) || 3001
const ownerIdPattern = /^[\w-]{8,80}$/

app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }))
app.use(express.json({ limit: '30kb' }))

function validateOwnerId(ownerId, response) {
  if (!ownerIdPattern.test(ownerId)) {
    response.status(400).json({ error: 'Invalid browser profile ID.' })
    return false
  }
  return true
}

function sendCart(cart, response) {
  response.json({
    items: cart.items.map((item) => ({
      id: item.productId,
      name: item.name,
      category: item.category,
      price: item.price,
      image: item.image,
      quantity: item.quantity,
    })),
  })
}

app.get('/api/health', (_request, response) => {
  response.json({ status: 'ok', database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' })
})

app.get('/api/products', (_request, response) => response.json(products))

app.get('/api/cart/:ownerId', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const cart = await Cart.findOne({ ownerId: request.params.ownerId })
  if (!cart) return response.json({ items: [] })
  sendCart(cart, response)
})

app.post('/api/cart/:ownerId/items', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const productId = request.body?.productId
  const product = products.find((item) => item.id === productId)
  if (!product) return response.status(404).json({ error: 'Product not found.' })

  const cart = await Cart.findOneAndUpdate(
    { ownerId: request.params.ownerId },
    { $setOnInsert: { ownerId: request.params.ownerId } },
    { new: true, upsert: true, setDefaultsOnInsert: true },
  )
  const item = cart.items.find((entry) => entry.productId === product.id)
  if (item) item.quantity += 1
  else cart.items.push({
    productId: product.id,
    name: product.name,
    category: product.category,
    price: product.price,
    image: product.image,
    quantity: 1,
  })
  await cart.save()
  sendCart(cart, response)
})

app.patch('/api/cart/:ownerId/items/:productId', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const quantity = request.body?.quantity
  if (!Number.isInteger(quantity) || quantity < 0 || quantity > 99) {
    return response.status(400).json({ error: 'Quantity must be a whole number between 0 and 99.' })
  }

  const cart = await Cart.findOne({ ownerId: request.params.ownerId })
  if (!cart) return response.status(404).json({ error: 'Cart not found.' })
  const item = cart.items.find((entry) => entry.productId === request.params.productId)
  if (!item) return response.status(404).json({ error: 'Cart item not found.' })
  if (quantity === 0) cart.items = cart.items.filter((entry) => entry.productId !== request.params.productId)
  else item.quantity = quantity
  await cart.save()
  sendCart(cart, response)
})

app.delete('/api/cart/:ownerId/items/:productId', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  await Cart.updateOne(
    { ownerId: request.params.ownerId },
    { $pull: { items: { productId: request.params.productId } } },
  )
  const cart = await Cart.findOne({ ownerId: request.params.ownerId })
  return cart ? sendCart(cart, response) : response.json({ items: [] })
})

app.delete('/api/cart/:ownerId', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  await Cart.updateOne({ ownerId: request.params.ownerId }, { $set: { items: [] } })
  response.json({ items: [] })
})

async function getPetProfile(ownerId) {
  let profile = await PetProfile.findOneAndUpdate(
    { ownerId },
    { $setOnInsert: { ownerId } },
    { new: true, upsert: true, setDefaultsOnInsert: true },
  )

  if (!profile.initialized) {
    await PetProfile.updateOne(
      { ownerId, initialized: false },
      { $set: { initialized: true, pets: defaultTrackedPets } },
    )
    profile = await PetProfile.findOne({ ownerId })
  }
  return profile
}

app.get('/api/tracking/:ownerId', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const profile = await getPetProfile(request.params.ownerId)
  response.json(profile.pets)
})

app.post('/api/tracking/:ownerId/pets', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const { name, breed, age, petId } = request.body || {}
  if (![name, breed, age, petId].every((value) => typeof value === 'string' && value.trim())) {
    return response.status(400).json({ error: 'Name, breed, age, and pet ID are required.' })
  }

  const profile = await getPetProfile(request.params.ownerId)
  if (profile.pets.some((pet) => pet.petId.toLowerCase() === petId.trim().toLowerCase())) {
    return response.status(409).json({ error: 'That pet ID is already in this profile.' })
  }
  profile.pets.unshift({
    id: randomUUID(),
    name: name.trim(),
    breed: breed.trim(),
    age: age.trim(),
    petId: petId.trim(),
    vaccinationStatus: request.body.vaccinationStatus?.trim() || 'Current',
    nextAppointment: request.body.nextAppointment?.trim() || 'Next review soon',
    lostPetStatus: request.body.lostPetStatus?.trim() || 'Safe at home',
    image: request.body.image?.trim() || '',
    recentActivity: 'Profile added to tracking dashboard',
    reminders: [],
  })
  await profile.save()
  response.status(201).json(profile.pets)
})

app.put('/api/tracking/:ownerId/pets/:petId', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const { name, breed, age, petId } = request.body || {}
  if (![name, breed, age, petId].every((value) => typeof value === 'string' && value.trim())) {
    return response.status(400).json({ error: 'Name, breed, age, and pet ID are required.' })
  }
  const profile = await getPetProfile(request.params.ownerId)
  const pet = profile.pets.find((entry) => entry.id === request.params.petId)
  if (!pet) return response.status(404).json({ error: 'Pet profile not found.' })
  if (profile.pets.some((entry) => entry.id !== pet.id && entry.petId.toLowerCase() === petId.trim().toLowerCase())) {
    return response.status(409).json({ error: 'That pet ID is already in this profile.' })
  }
  for (const field of ['name', 'breed', 'age', 'petId', 'vaccinationStatus', 'nextAppointment', 'lostPetStatus', 'image']) {
    if (typeof request.body[field] === 'string') pet[field] = request.body[field].trim()
  }
  await profile.save()
  response.json(profile.pets)
})

app.delete('/api/tracking/:ownerId/pets/:petId', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const profile = await getPetProfile(request.params.ownerId)
  profile.pets = profile.pets.filter((pet) => pet.id !== request.params.petId)
  await profile.save()
  response.json(profile.pets)
})

app.patch('/api/tracking/:ownerId/pets/:petId/vaccination', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const status = request.body?.status?.trim()
  if (!status || status.length > 200) return response.status(400).json({ error: 'Enter a vaccination status of up to 200 characters.' })
  const profile = await getPetProfile(request.params.ownerId)
  const pet = profile.pets.find((entry) => entry.id === request.params.petId)
  if (!pet) return response.status(404).json({ error: 'Pet profile not found.' })
  pet.vaccinationStatus = status
  pet.recentActivity = `Vaccination updated: ${status}`
  await profile.save()
  response.json(profile.pets)
})

app.post('/api/tracking/:ownerId/pets/:petId/reminders', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const text = request.body?.text?.trim()
  if (!text || text.length > 200) return response.status(400).json({ error: 'Enter a reminder of up to 200 characters.' })
  const profile = await getPetProfile(request.params.ownerId)
  const pet = profile.pets.find((entry) => entry.id === request.params.petId)
  if (!pet) return response.status(404).json({ error: 'Pet profile not found.' })
  pet.reminders.push({ id: randomUUID(), text, done: false })
  await profile.save()
  response.json(profile.pets)
})

app.patch('/api/tracking/:ownerId/pets/:petId/reminders/:reminderId', async (request, response) => {
  if (!validateOwnerId(request.params.ownerId, response)) return
  const profile = await getPetProfile(request.params.ownerId)
  const pet = profile.pets.find((entry) => entry.id === request.params.petId)
  const reminder = pet?.reminders.find((entry) => entry.id === request.params.reminderId)
  if (!reminder) return response.status(404).json({ error: 'Reminder not found.' })
  reminder.done = !reminder.done
  await profile.save()
  response.json(profile.pets)
})

app.post('/api/contact', async (request, response) => {
  const { name, email, subject, message } = request.body || {}
  if (![name, email, subject, message].every((value) => typeof value === 'string' && value.trim())) {
    return response.status(400).json({ error: 'Complete every contact form field.' })
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return response.status(400).json({ error: 'Enter a valid email address.' })
  }
  if (name.length > 100 || email.length > 254 || subject.length > 150 || message.trim().length < 10 || message.length > 3000) {
    return response.status(400).json({ error: 'Check the contact form field lengths and message length.' })
  }
  await ContactMessage.create({ name, email, subject, message })
  response.status(201).json({ message: 'Your message has been saved. Thank you for contacting Pet Hub.' })
})

app.use((error, _request, response, _next) => {
  console.error(error)
  const status = error.status >= 400 && error.status < 500
    ? error.status
    : error.name === 'ValidationError' ? 400 : 500
  response.status(status).json({ error: status === 400 ? 'Submitted data is invalid.' : 'The server could not complete this request.' })
})

async function startServer() {
  if (!process.env.MONGODB_URI) {
    throw new Error('MONGODB_URI is missing. Copy .env.example to .env and configure MongoDB.')
  }
  await mongoose.connect(process.env.MONGODB_URI)
  app.listen(port, () => {
    console.log(`Pet Hub API listening on http://localhost:${port}`)
  })
}

startServer().catch((error) => {
  console.error(`Pet Hub API could not start: ${error.message}`)
  process.exitCode = 1
})
