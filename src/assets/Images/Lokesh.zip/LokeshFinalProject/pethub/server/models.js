import mongoose from 'mongoose'

const reminderSchema = new mongoose.Schema(
  {
    id: { type: String, required: true },
    text: { type: String, required: true },
    done: { type: Boolean, default: false },
  },
  { _id: false },
)

const trackedPetSchema = new mongoose.Schema(
  {
    id: { type: String, required: true },
    name: { type: String, required: true, trim: true },
    breed: { type: String, required: true, trim: true },
    age: { type: String, required: true, trim: true },
    petId: { type: String, required: true, trim: true },
    vaccinationStatus: { type: String, default: 'Current' },
    nextAppointment: { type: String, default: 'Next review soon' },
    recentActivity: { type: String, default: 'Profile added to tracking dashboard' },
    lostPetStatus: { type: String, default: 'Safe at home' },
    image: { type: String, default: '' },
    reminders: { type: [reminderSchema], default: [] },
  },
  { _id: false },
)

export const PetProfile = mongoose.model(
  'PetProfile',
  new mongoose.Schema(
    {
      ownerId: { type: String, required: true, unique: true },
      initialized: { type: Boolean, default: false },
      pets: { type: [trackedPetSchema], default: [] },
    },
    { timestamps: true },
  ),
)

const cartItemSchema = new mongoose.Schema(
  {
    productId: { type: String, required: true },
    name: { type: String, required: true },
    category: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    image: { type: String, default: '' },
    quantity: { type: Number, required: true, min: 1 },
  },
  { _id: false },
)

export const Cart = mongoose.model(
  'Cart',
  new mongoose.Schema(
    {
      ownerId: { type: String, required: true, unique: true },
      items: { type: [cartItemSchema], default: [] },
    },
    { timestamps: true },
  ),
)

export const ContactMessage = mongoose.model(
  'ContactMessage',
  new mongoose.Schema(
    {
      name: { type: String, required: true, trim: true, maxlength: 100 },
      email: { type: String, required: true, trim: true, lowercase: true, maxlength: 254 },
      subject: { type: String, required: true, trim: true, maxlength: 150 },
      message: { type: String, required: true, trim: true, maxlength: 3000 },
    },
    { timestamps: true },
  ),
)
