# Pet Hub

Pet Hub is a responsive pet discovery and care website built with React, Vite, Tailwind CSS, React Router DOM, and React Icons. The API uses Node.js, Express, and MongoDB.

## Setup

1. Install the project dependencies:

   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env`. Set `MONGODB_URI` to your local MongoDB address or MongoDB Atlas connection string. Keep the real URI private and do not commit `.env`.

3. Start the API and frontend in separate terminals:

   ```bash
   npm run dev:backend
   ```

   ```bash
   npm run dev
   ```

   The frontend runs at `http://localhost:5173` and proxies `/api` requests to the API at `http://localhost:3001`.

## Backend API

- `GET /api/health` — API and database status
- `GET /api/products` — available accessory products
- `GET /api/cart/:ownerId` — read a browser's cart
- `POST /api/cart/:ownerId/items` — add a product by ID
- `PATCH /api/cart/:ownerId/items/:productId` — set quantity
- `DELETE /api/cart/:ownerId/items/:productId` — remove an item
- `DELETE /api/cart/:ownerId` — empty the cart
- `GET /api/tracking/:ownerId` — read tracked pets
- `POST /api/tracking/:ownerId/pets` — add a pet profile
- `PUT /api/tracking/:ownerId/pets/:petId` — edit a profile
- `DELETE /api/tracking/:ownerId/pets/:petId` — delete a profile
- `POST /api/tracking/:ownerId/pets/:petId/reminders` — add a reminder
- `PATCH /api/tracking/:ownerId/pets/:petId/reminders/:reminderId` — toggle a reminder
- `PATCH /api/tracking/:ownerId/pets/:petId/vaccination` — update vaccination status
- `POST /api/contact` — validate and save a contact message

Browser profile IDs are stored locally to associate demo carts and pet profiles. This prototype does not include user accounts or authentication, so do not use it to store private or sensitive information.

## Images

Pet Hub currently displays no photos. Uploaded files may remain in `src/assets/`, but the application does not import or display them.

## Build and lint

```bash
npm run build
npm run lint
```
